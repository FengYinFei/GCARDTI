import torch
from torch import nn
from torch_geometric.nn import GCNConv
from torch_geometric.nn import GATConv
import torch.nn.functional as F
torch.backends.cudnn.enabled = False

class GCN(nn.Module):
    def __init__(self, args):
        """
        :param args: Arguments object.
        """
        super(GCN, self).__init__()
        self.args = args
        self.gcn_drug1_f = GCNConv(self.args.fdrug, self.args.fdrug)
        self.gcn_drug2_f = GCNConv(self.args.fdrug, self.args.fdrug)
    
        self.gcn_target1_f = GCNConv(self.args.ftarget, self.args.ftarget)
        self.gcn_target2_f = GCNConv(self.args.ftarget, self.args.ftarget)
        
        
        # 调用gcn
        self.cnn_drug = nn.Conv1d(in_channels=self.args.gcn_layers,
                               out_channels=self.args.out_channels,
                               kernel_size=(self.args.fdrug, 1),
                               stride=1,
                               bias=True)
        self.cnn_target = nn.Conv1d(in_channels=self.args.gcn_layers,
                               out_channels=self.args.out_channels,
                               kernel_size=(self.args.ftarget, 1),
                               stride=1,
                               bias=True)
        # 调用gat，注意机制头数
        self.gat_drug1_f = GATConv(self.args.fdrug, self.args.fdrug,heads=4,concat=False,edge_dim=1)

        self.gat_target1_f = GATConv(self.args.ftarget, self.args.ftarget,heads=4,concat=False,edge_dim=1)


    def forward(self, data):
        torch.manual_seed(1)
        x_drug = torch.randn(self.args.drug_number, self.args.fdrug)
        x_target = torch.randn(self.args.target_number, self.args.ftarget)


        x_drug_f1 = torch.relu(self.gcn_drug1_f(x_drug.cuda(), data['cc']['edges'].cuda(), data['cc']['data_matrix'][data['cc']['edges'][0], data['cc']['edges'][1]].cuda()))
        x_drug_att= torch.relu(self.gat_drug1_f(x_drug_f1,data['cc']['edges'].cuda(),data['cc']['data_matrix'][data['cc']['edges'][0], data['cc']['edges'][1]].cuda()))
        x_drug_f2 = torch.relu(self.gcn_drug2_f(x_drug_att, data['cc']['edges'].cuda(), data['cc']['data_matrix'][data['cc']['edges'][0], data['cc']['edges'][1]].cuda()))
       

        x_target_f1 = torch.relu(self.gcn_target1_f(x_target.cuda(), data['dd']['edges'].cuda(), data['dd']['data_matrix'][data['dd']['edges'][0], data['dd']['edges'][1]].cuda()))
        x_target_att =torch.relu(self.gat_target1_f(x_target_f1, data['dd']['edges'].cuda(),data['dd']['data_matrix'][data['dd']['edges'][0], data['dd']['edges'][1]].cuda()))        
        x_target_f2 = torch.relu(self.gcn_target2_f(x_target_att, data['dd']['edges'].cuda(), data['dd']['data_matrix'][data['dd']['edges'][0], data['dd']['edges'][1]].cuda()))

        # 将上面得到的.cat()拼接.t()然后转置
        X_drug = torch.cat((x_drug_f1, x_drug_f2), 1).t()
        # view()的作用相当于numpy中的reshape，重新定义矩阵的形状
        X_drug = X_drug.view(1, self.args.gcn_layers, self.args.fdrug, -1)

        X_target = torch.cat((x_target_f1, x_target_f2), 1).t()
        X_target = X_target.view(1, self.args.gcn_layers, self.args.ftarget, -1)
    
        drug_fea = self.cnn_drug(X_drug)
        drug_fea = drug_fea.view(self.args.out_channels, self.args.drug_number).t()

        target_fea = self.cnn_target(X_target)
        target_fea = target_fea.view(self.args.out_channels, self.args.target_number).t()

        return drug_fea.mm(target_fea.t()),drug_fea,target_fea
#多层感知机
class MLPLayer(torch.nn.Module):

    def __init__(self, layers):
        super(MLPLayer, self).__init__()
        self.layers = layers
        self.num_layers = len(layers)
        self.mlp_layers = nn.ModuleList()
        for num_layer in range(0, self.num_layers-1): # [64, 16, 1]
            self.mlp_layers.append(torch.nn.Linear(self.layers[num_layer], self.layers[num_layer+1]))

    def forward(self, lncx, disx):
        lnc_size = lncx.shape[0]
        dis_size = disx.shape[0]
        lnc_temp = lncx.repeat(1, dis_size).view(lnc_size * dis_size, -1)
        dis_temp = disx.repeat(lnc_size, 1)
        z = torch.cat([lnc_temp, dis_temp], dim=1).view(lnc_size * dis_size, -1)

        if self.num_layers < 3:
            z = self.mlp_layers[0](z)
        else:
            for num_layer in range(0, self.num_layers - 2):
                z = self.mlp_layers[num_layer](z)
                F.elu(z)
            z = self.mlp_layers[self.num_layers - 2](z)

        output = z.view(lnc_size, dis_size)
        return F.sigmoid(output)








