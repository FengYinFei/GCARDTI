import csv
import torch
import random
import numpy as np
  
 #读取数据模块，返回成张量
def read_csv(path):
    with open(path, 'r', newline='') as csv_file:
        reader = csv.reader(csv_file)
        cd_data = []
        cd_data += [[float(i) for i in row] for row in reader]# 列表解析式
        return torch.Tensor(cd_data)
    
# 得到每条边的索引
def get_edge_index(matrix):
    edge_index = [[], []]
    for i in range(matrix.size(0)):# for循环嵌套，输出边
        for j in range(matrix.size(1)):
            if matrix[i][j] != 0:
                edge_index[0].append(i)
                edge_index[1].append(j)
    return torch.LongTensor(edge_index)# 返回torch.LongTensor是64位整型

# 定义数据，将数据存为字典
def dataset(args):
    dataset = dict()
#  *************************************************************************************************************
    dataset['c_d'] = read_csv(args.dataset_path + '/drug_protein400_500.csv')
    

    zero_index = []
    one_index = []
    cd_pairs = []
    # 循环输出关联矩阵中的0，1值，并存入定义好的列表中
    for i in range(dataset['c_d'].size(0)):
        for j in range(dataset['c_d'].size(1)):
            if dataset['c_d'][i][j] < 1:
                zero_index.append([i, j, 0])
            if dataset['c_d'][i][j] >= 1:
                one_index.append([i, j, 1])
# random.sample用于截取列表的指定长度的随机数，但是不会改变列表本身的排序，
# 用法random.sample（列表，大小）
    cd_pairs = random.sample(zero_index, len(one_index)) + one_index
# *************************************************************************************************************
    dd_matrix = read_csv(args.dataset_path + '/proteinfeature500.csv')# 读取数据靶标数据
    dd_edge_index = get_edge_index(dd_matrix)# 调用函数得到边值的索引
    dataset['dd'] = {'data_matrix': dd_matrix, 'edges': dd_edge_index}# 定义字典
# *************************************************************************************************************
    cc_matrix = read_csv(args.dataset_path + '/drugfeature400.csv')# 读取药物数据
    cc_edge_index = get_edge_index(cc_matrix)
    dataset['cc'] = {'data_matrix': cc_matrix, 'edges': cc_edge_index}

    return dataset, cd_pairs

# 特征表示
def feature_representation(model, args, dataset):
    model.cuda()
    # 优化器，adam优化器，学习率
# *************************************************************************************************************
    optimizer = torch.optim.Adam(model.parameters(), lr=0.0001)
    model = train(model, dataset, optimizer, args)# 调用模型的训练函数
    #  eval函数就是实现list、dict、tuple与str之间的转化，同样str函数把list，dict，tuple转为为字符串
    model.eval()
    # 在pytorch中，tensor有一个requires_grad参数，如果设置为True，则反向传播时，该tensor就会自动求导。
    # tensor的requires_grad的属性默认为False,若一个节点（叶子变量：自己创建的tensor）requires_grad被设置为True，
    # 那么所有依赖它的节点requires_grad都为True（即使其他相依赖的tensor的requires_grad = False）
    # 当requires_grad设置为False时,反向传播时就不会自动求导了，因此大大节约了显存或者说内存。
    # with torch.no_grad的作用
    # 在该模块下，所有计算得出的tensor的requires_grad都自动设置为False
    with torch.no_grad():
        score, drug_fea, target_fea = model(dataset)# 实例化三个对象
    drug_fea = drug_fea.cpu().detach().numpy()# 该方法主要用于将cpu上的tensor转为numpy数据。
    target_fea = target_fea.cpu().detach().numpy()
    return score, drug_fea, target_fea

# 新数据，预测数据
def new_dataset(drug_fea, target_fea, cd_pairs):
    unknown_pairs = []
    known_pairs = []
    
    for pair in cd_pairs:
        if pair[2] == 1:
            known_pairs.append(pair[:2])
            
        if pair[2] == 0:
            unknown_pairs.append(pair[:2])
    
    
    
    print("--------------------")
    print(drug_fea.shape,target_fea.shape)
    print("--------------------")
    print(len(unknown_pairs), len(known_pairs))
    
    nega_list = []
    for i in range(len(unknown_pairs)):
        # 遍历得到的特征转换为列表进行拼接起来
        nega = drug_fea[unknown_pairs[i][0],:].tolist() + target_fea[unknown_pairs[i][1],:].tolist()+[0,1]
        nega_list.append(nega)
        
    posi_list = []
    for j in range(len(known_pairs)):
        posi = drug_fea[known_pairs[j][0],:].tolist() + target_fea[known_pairs[j][1],:].tolist()+[1,0]
        posi_list.append(posi)
    # 未知的和已知的特征相加
    samples = posi_list + nega_list
    # random.shuffle()用于将一个列表中的元素打乱顺序
    random.shuffle(samples)
    # 将得到列表创建一个数组
    samples = np.array(samples)
    return samples
# 定义关联矩阵
def C_Dmatix(cd_pairs,trainindex,testindex):
# ************************************************************************************************************
    c_dmatix = np.zeros((400,500))# 返回一个输入矩阵的大小的0矩阵
    for i in trainindex:
        if cd_pairs[i][2]==1:# 如果该矩阵的[i][2]为1，则该矩阵的i行i列为1
            c_dmatix[cd_pairs[i][0]][cd_pairs[i][1]]=1
    
    
    dataset = dict()
    cd_data = []
    cd_data += [[float(i) for i in row] for row in c_dmatix]# 列表的解析
    cd_data = torch.Tensor(cd_data)# 转换为张量
    dataset['c_d'] = cd_data # 给字典赋值
    
    train_cd_pairs = []
    test_cd_pairs = []
    for m in trainindex:
        train_cd_pairs.append(cd_pairs[m])
    
    for n in testindex:
        test_cd_pairs.append(cd_pairs[n])

    return dataset['c_d'],train_cd_pairs,test_cd_pairs

# 训练过程
def train(model, train_data, optimizer, opt):
    model.train()
    for epoch in range(0, opt.epoch):
        model.zero_grad()
        score,x,y = model(train_data)
        # nn.BCEloss()二分类交叉熵，输入值取值在[0,1]
        # BCEWithLogitsLoss，此损失函数将 Sigmoid 层和 BCELoss 整合在一起
        loss = torch.nn.BCEWithLogitsLoss(reduction='mean')
        loss = loss(score, train_data['c_d'].cuda())
        loss.backward()
        optimizer.step()
        print(loss.item())
    score = score.detach().cpu().numpy()
# ************************************************************************************************************
    np.savetxt('E:/代码参考/GCARDTI/GCARDTI-main/results/NEDTP-400_500.txt'
               ,score*-1*0.01,fmt='%0.05f',delimiter=',')
    return model