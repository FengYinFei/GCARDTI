import pandas as pd
import selfies as sf
import numpy as np
from gensim.models import Word2Vec
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
df = pd.read_csv('drug.csv')
print(df)

df['SMILES']=df['SMILES'].astype(str)
df = df.dropna()
df['SMILES'][0]
df['selfies']='Nan'

for i in range(0,100  ):
    try:
        df['selfies'][i]= sf.encoder(df['SMILES'][i])
    except:
        df['selfies'][i]=np.nan

df = df.dropna().reset_index()
array=list(df['selfies'])
print(array)


f = open("drugself.txt", "w")
for i in array:
 f.writelines(i+'\n')

for i in range(0,100):
    array[i]=array[i].split('][')
    array[i][0]=array[i][0].replace('[', '')
    array[i][-1]=array[i][-1].replace(']', '')

model = Word2Vec(sentences=array, vector_size=100, window=5, min_count=1, workers=4)
model.save("word2vec.model")
model.build_vocab(array)
vector=model.wv['C']
sims = model.wv.most_similar('C', topn=10)
word_vectors = model.wv

documents = [TaggedDocument(doc, [i]) for i, doc in enumerate(array)]
model = Doc2Vec(documents, vector_size=100, window=2, min_count=1, workers=4)
matrix=model.dv.get_normed_vectors()
df_dv=pd.DataFrame(matrix.tolist())
df_new = pd.concat([df, df_dv], axis=1)
df_new.to_csv('drug_dv.csv')