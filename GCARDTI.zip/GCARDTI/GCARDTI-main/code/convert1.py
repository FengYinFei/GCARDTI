import numpy as np
import pandas as pd

txt = np.loadtxt('E:\代码参考\GCARDTI\GCARDTI-main\HampDTI\simdrugfeanormalize.txt')
txtDF = pd.DataFrame(txt)
txtDF.to_csv('E:\代码参考\GCARDTI\GCARDTI-main\HampDTI\simdrugfeanormalize.csv', index=False)
