#Open the CSV file in reading mode and the TXT file in writing mode
with open('E:\代码参考\GCARDTI\GCARDTI-main\HampDTI\drugfeanormalize.csv', 'r') as f_in, open('E:\代码参考\GCARDTI\GCARDTI-main\HampDTI\drugfeanormalize.txt', 'w') as f_out:

    # 2. Read the CSV file and store in variable
    content = f_in.read()

    # 3. Write the content into the TXT file
    f_out.write(content)

