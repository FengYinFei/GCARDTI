
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

import pandas as pd

m1 = np.loadtxt('E:\代码参考\GCARDTI\GCARDTI-main\HampDTI\drugfeanormalize.txt')

m1_similarity = cosine_similarity(m1)

np.savetxt('E:\代码参考\GCARDTI\GCARDTI-main\HampDTI\simdrugfeanormalize.txt',m1_similarity,fmt='%0.05f',delimiter=',')