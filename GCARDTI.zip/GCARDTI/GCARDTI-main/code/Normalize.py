#加载模块
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings("ignore") #过滤掉警告的意思
from pyforest import *
import pandas as pd
import numpy as np
#读入数据
data=pd.read_csv("/GCARDTI-main/HampDTI/drugfeature.csv", encoding='gbk') #bgk表示中文编码
#查看数据前五行
data.head()
from sklearn.preprocessing import MinMaxScaler
#区间缩放，返回值为缩放到[0, 1]区间的数据
Standard_data=MinMaxScaler().fit_transform(data)
#由于标准化后的数据是array格式，故将其转化为数据框
Standard_data = pd.DataFrame(Standard_data) #转为dataframe
#将数据写成csv文件，方便后续的建模
Standard_data.to_csv("E:\代码参考\GCARDTI\GCARDTI-main\HampDTI\drugfeature.csv",index=False)
