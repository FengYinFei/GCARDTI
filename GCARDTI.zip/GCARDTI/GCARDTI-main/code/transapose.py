
import numpy as np
data = np.loadtxt('E:\代码参考\GCARDTI\GCARDTI-main\DTI-HETA\Total-data\e_Amat.txt')
f = np.transpose(data)
np.savetxt('E:\代码参考\GCARDTI\GCARDTI-main\DTI-HETA\Total-data\e_Amat.txt', f,"%d",)